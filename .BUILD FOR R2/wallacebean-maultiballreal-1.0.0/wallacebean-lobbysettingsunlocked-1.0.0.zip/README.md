

credits and shoutouts to ME!!!!!! FUCKING ME!!!!!!!!!
